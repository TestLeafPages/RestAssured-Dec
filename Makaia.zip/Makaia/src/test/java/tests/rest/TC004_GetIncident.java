package tests.rest;

import java.io.File;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.restassured.response.Response;
import lib.rest.RESTAssuredBase;


public class TC004_GetIncident extends RESTAssuredBase{

	@BeforeTest//Report test case details
	public void setValues() {

		testCaseName = "TC004_GetIncident (REST)";
		testDescription = "Get All Incident and Verify";
		nodes = "Incident";
		authors = "sarath";
		category = "REST";
	}

	@Test
	public void getIncident() {		
		
		// get the request
		Response response = get("table/incident", "sysparm_limit", "20");	
		
		// Verify the Content type
		verifyContentType(response, "JSON");
		
		// Verify the response status code
		verifyResponseCode(response, 200);	
		
		// Verify the response time
		verifyResponseTime(response, 10000);
		
	}


}





